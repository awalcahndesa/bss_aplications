-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 04 Mar 2017 pada 08.18
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bss_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_beasiswa`
--

CREATE TABLE `bss_beasiswa` (
  `no_beasiswa` varchar(210) NOT NULL,
  `no_user` varchar(210) NOT NULL,
  `nama_beasiswa` varchar(390) DEFAULT NULL,
  `keterangan` text,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_beasiswa`
--

INSERT INTO `bss_beasiswa` (`no_beasiswa`, `no_user`, `nama_beasiswa`, `keterangan`, `status`) VALUES
('BS24SS160117', 'SS160117', 'BMT MARHAMAH', 'NMN ASDa', 1),
('BS77710GS160116', 'SS160117', 'Bantuan Siswa Miskin 1', 'Beasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa Basd Easiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa BEasiswa yang ditujukan untuk siswa yang kurang mampu beasiswa beasiswa ', 1),
('BS9088732SS160117', 'SS160117', 'APBN', 'Beasiswa yang hanya ditujukan kepada siswa kurang mampu', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_chat`
--

CREATE TABLE `bss_chat` (
  `id_chat` varchar(201) NOT NULL,
  `no_penerima` varchar(201) NOT NULL,
  `no_pengirim` varchar(201) NOT NULL,
  `isi` text NOT NULL,
  `file` varchar(201) NOT NULL,
  `tgl` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_chat`
--

INSERT INTO `bss_chat` (`id_chat`, `no_penerima`, `no_pengirim`, `isi`, `file`, `tgl`, `status`) VALUES
('132', 'SS160117', 'SS1601171', 'dkajksd asd', '', '2017-02-07 13:36:47', 0),
('SS16011712', 'SS160117', 'SS1601171', 'dkajksd asdasd', '', '2017-02-07 13:36:47', 0),
('SS160117122', 'SS160117w', 'SS160117', 'dkajksd asdasd', '', '2017-02-07 13:36:59', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_comment`
--

CREATE TABLE `bss_comment` (
  `no_coment` int(11) NOT NULL,
  `no_induk` varchar(260) NOT NULL,
  `no_user` varchar(290) NOT NULL,
  `comment` text NOT NULL,
  `tgl_comment` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_comment`
--

INSERT INTO `bss_comment` (`no_coment`, `no_induk`, `no_user`, `comment`, `tgl_comment`, `status`) VALUES
(1, 'BS77710GS160116', 'SS20174412112880', 'okekkakrdalskj ', '2017-02-05', 1),
(2, 'B12017', 'SS20174412112880', 'oke alskdaos asdoasndm oasdka', '2017-02-05', 1),
(3, 'B12017', 'SS20174412112880', 'oke alskdaos asdoasndm oasdkaasdasd', '2017-02-05', 1),
(4, 'B12017', 'SS20174412112880', 'kodoas', '2017-02-05', 1),
(5, 'BS93102038SS160117', 'SS20174412112880', 'okekkakrdalskj ', '2017-02-05', 1),
(6, 'BS24SS160117', 'SS20174412112880', 'oke alskdaos asdoasndm oasdka', '2017-02-05', 1),
(7, 'B12017', 'SS201744121128000', 'asds', '2017-02-05', 1),
(8, 'BS77710GS160116', 'SS20174412112880', 'awal', '2017-02-06', 1),
(9, 'BS24SS160117', 'SS2017441211234567', 'komen', '2017-02-08', 1),
(10, 'B12017', 'SS20174412112880', 'asd', '2017-02-23', 1),
(11, 'BS24SS160117', 'SS201744121999999', 'jasd', '2017-03-02', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_f_profile`
--

CREATE TABLE `bss_f_profile` (
  `no_user` varchar(210) DEFAULT NULL,
  `foto` varchar(210) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_f_profile`
--

INSERT INTO `bss_f_profile` (`no_user`, `foto`, `status`) VALUES
('SS160117', 'avatar5.png', 1),
('GS160116', 'avatar.png', 1),
('SS20174412112880', 'avatar04.png', 1),
('SS201744121128888', 'SS201744121128888Screenshot at 2017-01-23 12-58-22.png', 1),
('SS201744121120000', 'SS201744121120000Screenshot at 2017-01-21 12-24-47.png', 1),
('SS2017441211909123', 'SS2017441211909123Screenshot at 2017-01-21 12-42-58.png', 1),
('SS201744121', 'SS201744121Screenshot at 2017-01-21 12-45-21.png', 1),
('GS201741211234555', 'GS201741211234555Screenshot at 2017-01-21 12-42-58.png', 1),
('GS20174121889092371', 'GS20174121889092371Screenshot at 2017-01-21 12-42-58.png', 1),
('SS201744121231232131231', 'SS201744121231232131231Screenshot at 2017-01-21 12-45-21.png', 1),
('SS201744121128000', 'SS201744121128000logo.png', 1),
('SS201744121129012', 'SS201744121129012procedure.png', 1),
('SS201744121453543', 'SS201744121453543Screenshot at 2017-02-04 09-22-29.png', 1),
('SS2017441211234567', 'SS2017441211234567procedure.png', 1),
('SS201744121999999', 'SS201744121999999201702272239201000.jpg', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_guru`
--

CREATE TABLE `bss_guru` (
  `nip` varchar(21) NOT NULL,
  `no_user` varchar(210) DEFAULT NULL,
  `nama_guru` varchar(210) DEFAULT NULL,
  `mapel` varchar(210) DEFAULT NULL,
  `no_kelas` int(11) DEFAULT NULL,
  `alamat` text,
  `ttl` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_guru`
--

INSERT INTO `bss_guru` (`nip`, `no_user`, `nama_guru`, `mapel`, `no_kelas`, `alamat`, `ttl`, `status`) VALUES
('12837126', 'SS160117', 'Guru BK', '-', 1, 'kadjkasnd', '2017-01-02', 1),
('889092371', 'GS20174121889092371', 'gurku', 'mapel', 4121, 'alamart', '2017-02-18', 1),
('918237823', 'GS160116', 'guru 23', 'mapel 1', 4121, 'ALAMA', '2017-01-03', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_jurusan`
--

CREATE TABLE `bss_jurusan` (
  `no_jurusan` int(11) NOT NULL,
  `nama_jurusan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_jurusan`
--

INSERT INTO `bss_jurusan` (`no_jurusan`, `nama_jurusan`) VALUES
(1, 'Akuntansi'),
(2, 'Administrasi Perkantoran'),
(3, 'Pemasaran'),
(4, 'Rekayasa Perangkat Lunak'),
(5, 'Teknik Komputer'),
(6, 'Tata Busana'),
(7, 'Budidaya Perikanan'),
(8, 'Teknik mekatronika'),
(990, '-');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_kelas`
--

CREATE TABLE `bss_kelas` (
  `no_kelas` int(11) NOT NULL,
  `no_jurusan` int(11) DEFAULT NULL,
  `nama_kelas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_kelas`
--

INSERT INTO `bss_kelas` (`no_kelas`, `no_jurusan`, `nama_kelas`) VALUES
(1, 990, '-'),
(4121, 4, 'XII RPL 1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_penerima`
--

CREATE TABLE `bss_penerima` (
  `no_penerima` varchar(210) NOT NULL,
  `no_pengajuan` varchar(210) NOT NULL,
  `no_beasiswa` varchar(210) NOT NULL,
  `besarnya` varchar(50) NOT NULL,
  `nis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_penerima`
--

INSERT INTO `bss_penerima` (`no_penerima`, `no_pengajuan`, `no_beasiswa`, `besarnya`, `nis`) VALUES
('BS24SS160117SS201744121123456714865162201234567', 'BS24SS160117SS20174412112345671486516220', 'BS24SS160117', '3000', 1234567),
('BS24SS160117SS2017441219999991488378577999999', 'BS24SS160117SS2017441219999991488378577', 'BS24SS160117', '3000', 999999),
('BS77710GS160116SS20174412112880148608856112880', 'BS77710GS160116SS201744121128801486088561', 'BS77710GS160116', '3000', 12880),
('BS9088732SS160117SS2017441211280001486129192128000', 'BS9088732SS160117SS2017441211280001486129192', 'BS9088732SS160117', '3000', 128000),
('BS9088732SS160117SS2017441214535431486330436453543', 'BS9088732SS160117SS2017441214535431486330436', 'BS9088732SS160117', '3000', 453543);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_pengajuan`
--

CREATE TABLE `bss_pengajuan` (
  `no_pengajuan` varchar(201) NOT NULL,
  `no_beasiswa` varchar(201) NOT NULL,
  `no_user` varchar(201) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_pengajuan`
--

INSERT INTO `bss_pengajuan` (`no_pengajuan`, `no_beasiswa`, `no_user`, `status`) VALUES
('BS24SS160117SS2017441219999991488378577', 'BS24SS160117', 'SS201744121999999', 3),
('BS77710GS160116SS201744121128801486088561', 'BS77710GS160116', 'SS20174412112880', 3),
('BS9088732SS160117SS2017441211280001486129192', 'BS9088732SS160117', 'SS201744121128000', 3),
('BS9088732SS160117SS2017441214535431486330436', 'BS9088732SS160117', 'SS201744121453543', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_peringkat`
--

CREATE TABLE `bss_peringkat` (
  `no_peringkat` int(11) NOT NULL,
  `juara` int(11) NOT NULL,
  `tingkat` varchar(50) NOT NULL,
  `besarnya_reward` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_peringkat`
--

INSERT INTO `bss_peringkat` (`no_peringkat`, `juara`, `tingkat`, `besarnya_reward`) VALUES
(1, 1, 'PROVINSI', 8000),
(2, 1, 'KABUPATEN', 800),
(3, 3, 'PROVINSI', 5000),
(4, 2, 'PROVINSI', 8000),
(6, 3, 'KABUPATEN', 5000),
(8, 2, 'KARISIDENAN', 800),
(10, 1, 'NASIONAL', 8000),
(11, 3, 'NASIONAL', 5000),
(13, 2, 'NASIONAL', 8000),
(14, 2, 'KABUPATEN', 5000),
(15, 1, 'KARISIDENAN', 800),
(16, 3, 'KARISIDENAN', 800);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_prestasi`
--

CREATE TABLE `bss_prestasi` (
  `no_prestasi` int(50) NOT NULL,
  `nis` int(11) NOT NULL,
  `no_peringkat` int(11) NOT NULL,
  `kujuaraan` varchar(210) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_prestasi`
--

INSERT INTO `bss_prestasi` (`no_prestasi`, `nis`, `no_peringkat`, `kujuaraan`) VALUES
(2, 12880, 1, 'matematika');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_siswa`
--

CREATE TABLE `bss_siswa` (
  `nis` int(11) NOT NULL,
  `nisn` int(11) NOT NULL,
  `no_user` varchar(201) DEFAULT NULL,
  `nama_siswa` varchar(210) DEFAULT NULL,
  `no_kelas` int(11) DEFAULT NULL,
  `no_jurusan` int(11) DEFAULT NULL,
  `ttl` date DEFAULT NULL,
  `alamat` text,
  `no_hp` varchar(15) DEFAULT NULL,
  `nama_ayah` varchar(210) DEFAULT NULL,
  `nama_ibu` varchar(210) DEFAULT NULL,
  `nama_wali` varchar(210) DEFAULT NULL,
  `pekerjaan_ayah` varchar(210) DEFAULT NULL,
  `pekerjaan_ibu` varchar(210) DEFAULT NULL,
  `pekerjaan_wali` varchar(210) DEFAULT NULL,
  `alamat_ortu` text,
  `alamat_wali` text,
  `no_hp_ortu` varchar(16) DEFAULT NULL,
  `no_hp_wali` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_siswa`
--

INSERT INTO `bss_siswa` (`nis`, `nisn`, `no_user`, `nama_siswa`, `no_kelas`, `no_jurusan`, `ttl`, `alamat`, `no_hp`, `nama_ayah`, `nama_ibu`, `nama_wali`, `pekerjaan_ayah`, `pekerjaan_ibu`, `pekerjaan_wali`, `alamat_ortu`, `alamat_wali`, `no_hp_ortu`, `no_hp_wali`) VALUES
(12389, 0, 'SS160117', 'aawal', 1, 990, '2017-01-03', ' w plumbungan', '09283676814', 'ayah i', 'ibu i', '- d', 'kkerja', 'kkerja', 'k-', '9123', 'k-', '098762163', 'k'),
(12880, 1245678901, 'SS20174412112880', 'awal nurahmat deriyanto', 4121, 4, '1998-12-14', 'plumbungan', '08771522823677', 'khamto', 'tutur', '-', 'petani', 'kerja', '-', 'plumbungan', '-', '0987654456789', '-'),
(120000, 0, 'SS201744121120000', 'surya', 4121, 4, '2017-01-04', '3qeqwe', '12312123', 'qeqwe', 'eqwee', '-', 'eqwe', 'eqwe', '-', 'eqwe', '-', 'eqwe', '-'),
(128000, 0, 'SS201744121128000', 'asd', 4121, 4, '1985-12-31', 'plumbungan', '12312', 'ad', 'asd', '-', 'sdasd', 'dasd', '-', 'dasd', '-', 'dasd', '-'),
(129012, 0, 'SS201744121129012', 'oke', 4121, 4, '2017-02-08', 'quoieudaio', '009123800', 'oiueq', 'ouaoiueqo', '-', 'uoqiwueqo', 'euoqiwue', '-', 'ouioqwe', '-', 'euqoiwue', '-'),
(453543, 0, 'SS201744121453543', 'yuda', 4121, 4, '2017-02-12', 'banjar', '781632', 'ayah', 'ibu', '-', 'pns', 'pns', '-', 'banjar', '-', '0923781', '-'),
(999999, 0, 'SS201744121999999', 'awal 222', 4121, 4, '2017-03-09', 'asdd', '08771522', 'asds', 'asd', '-', 'asd', 'asd', '-', 'sad', '-', 'ad', '-'),
(1234567, 0, 'SS2017441211234567', 'nego', 4121, 4, '2017-02-10', 'htf', '7632', 'hf', 'hh', '-', 'f', 'jyjhgj', '-', 'fy6uyf', '-', 'jgutu', '-'),
(1909123, 0, 'SS2017441211909123', 'nego', 4121, 4, '2017-01-12', 'adaskdjk', '2312312412', 'akljsdkasjd', 'kajsldkjaskldj', '-', 'lkjdakljsdklajj', 'jkdajsdklasjdlk', '-', 'mopm', '-', '1909923', '-'),
(12389172, 0, 'SS20174412112389172', 'awal', 4121, 4, '2017-12-31', 'plumbungan', '087715228236', 'khamto', 'tutur', '-', 'petani', 'kerja', '-', 'plumbungan', '-', '1231234', '-');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_syarat`
--

CREATE TABLE `bss_syarat` (
  `no_syarat` int(11) NOT NULL,
  `no_beasiswa` varchar(210) DEFAULT NULL,
  `nama_syarat` varchar(210) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_syarat`
--

INSERT INTO `bss_syarat` (`no_syarat`, `no_beasiswa`, `nama_syarat`, `status`) VALUES
(58, 'BS24SS160117', 'syarat 2', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_up_syarat`
--

CREATE TABLE `bss_up_syarat` (
  `no_upload` varchar(210) NOT NULL,
  `no_syarat` int(11) DEFAULT NULL,
  `no_user` varchar(210) DEFAULT NULL,
  `no_pengajuan` varchar(210) NOT NULL,
  `nama_uploads` varchar(210) DEFAULT NULL,
  `file_uploads` varchar(210) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_up_syarat`
--

INSERT INTO `bss_up_syarat` (`no_upload`, `no_syarat`, `no_user`, `no_pengajuan`, `nama_uploads`, `file_uploads`) VALUES
('SS201744121123456758148651625558', 58, 'SS2017441211234567', 'BS24SS160117SS20174412112345671486516220', 'SS2017441211234567Screenshot at 2017-01-23 12-58-22.png', 'SS2017441211234567Screenshot at 2017-01-23 12-58-22.png\n'),
('SS20174412199999958148837860958', 58, 'SS201744121999999', 'BS24SS160117SS2017441219999991488378577', 'SS201744121999999201702272239201000.jpg', 'SS201744121999999201702272239201000.jpg\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bss_user`
--

CREATE TABLE `bss_user` (
  `no_user` varchar(201) NOT NULL,
  `username` varchar(201) NOT NULL,
  `pass` varchar(201) NOT NULL,
  `email` varchar(201) NOT NULL,
  `level` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bss_user`
--

INSERT INTO `bss_user` (`no_user`, `username`, `pass`, `email`, `level`, `status`) VALUES
('GS160116', 'guru', 'guru', 'guru@skanza.com', 2, 1),
('GS2017', '', '', '@skanza.com', 2, 0),
('GS201741211234555', '1234555', '1234555', '1234555@skanza.com', 2, 0),
('GS20174121889092371', '889092371', '889092371', '889092371@skanza.com', 2, 0),
('SS010317', '', '', '', 1, 1),
('SS160117', 'bk', 'awal', 'siswaskanza', 3, 0),
('SS170117', 'awalnur', 'awal', 'awal.nurahmat@gmail.com', 1, 1),
('SS2017', '', '', '@skanza.com', 1, 0),
('SS201711', '', '', '@skanza.com', 1, 0),
('SS2017111234567890', '1234567890', '1234567890', '1234567890@skanza.com', 1, 0),
('SS20174121', '', '', '@skanza.com', 1, 0),
('SS201744121', '', '', '@skanza.com', 1, 0),
('SS201744121120000', '120000', '120000', '120000@skanza.com', 1, 0),
('SS201744121123', '123', '123', '123@skanza.com', 1, 0),
('SS201744121123456', '1234567890', '1234567890', '1234567890@skanza.com', 1, 0),
('SS2017441211234567', '1234567', '1234567', '1234567@skanza.com', 1, 0),
('SS2017441211234567890', '1234567890', '1234567890', '1234567890@skanza.com', 1, 0),
('SS20174412112389172', '12389172', '12389172', '12389172@skanza.com', 1, 0),
('SS201744121123897', '123897', '123897', '123897@skanza.com', 1, 0),
('SS201744121128000', '128000', '128000', '128000@skanza.com', 1, 0),
('SS2017441211280123', '1280123', '1280123', '1280123@skanza.com', 1, 0),
('SS20174412112880', '12880', '12880', '12880@skanza.com', 1, 0),
('SS201744121128888', '128888', '128888', '128888@skanza.com', 1, 0),
('SS20174412112899', '12899', '12899', '12899@skanza.com', 1, 0),
('SS201744121129012', '129012', '129012', '129012@skanza.com', 1, 0),
('SS201744121129381298', '129381298', '129381298', '129381298@skanza.com', 1, 0),
('SS2017441211909123', '1909123', '1909123', '1909123@skanza.com', 1, 0),
('SS201744121231232131231', '231232131231', '231232131231', '231232131231@skanza.com', 1, 0),
('SS201744121453543', '453543', '453543', '453543@skanza.com', 1, 0),
('SS201744121999999', '999999', '999999', '999999@skanza.com', 1, 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view`
--
CREATE TABLE `view` (
`nama_beasiswa` varchar(390)
,`username` varchar(201)
,`keterangan` text
);

-- --------------------------------------------------------

--
-- Struktur untuk view `view`
--
DROP TABLE IF EXISTS `view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view`  AS  select `bss_beasiswa`.`nama_beasiswa` AS `nama_beasiswa`,`bss_user`.`username` AS `username`,`bss_beasiswa`.`keterangan` AS `keterangan` from (`bss_beasiswa` join `bss_user` on((`bss_user`.`no_user` = `bss_beasiswa`.`no_user`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bss_beasiswa`
--
ALTER TABLE `bss_beasiswa`
  ADD PRIMARY KEY (`no_beasiswa`),
  ADD KEY `no_user` (`no_user`);

--
-- Indexes for table `bss_chat`
--
ALTER TABLE `bss_chat`
  ADD PRIMARY KEY (`id_chat`),
  ADD KEY `no_penerima` (`no_penerima`),
  ADD KEY `no_pengirim` (`no_pengirim`);

--
-- Indexes for table `bss_comment`
--
ALTER TABLE `bss_comment`
  ADD PRIMARY KEY (`no_coment`);

--
-- Indexes for table `bss_f_profile`
--
ALTER TABLE `bss_f_profile`
  ADD KEY `no_user` (`no_user`);

--
-- Indexes for table `bss_guru`
--
ALTER TABLE `bss_guru`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `no_user` (`no_user`),
  ADD KEY `no_kelas` (`no_kelas`);

--
-- Indexes for table `bss_jurusan`
--
ALTER TABLE `bss_jurusan`
  ADD PRIMARY KEY (`no_jurusan`);

--
-- Indexes for table `bss_kelas`
--
ALTER TABLE `bss_kelas`
  ADD PRIMARY KEY (`no_kelas`),
  ADD KEY `no_kelas` (`no_kelas`),
  ADD KEY `no_jurusan` (`no_jurusan`);

--
-- Indexes for table `bss_penerima`
--
ALTER TABLE `bss_penerima`
  ADD PRIMARY KEY (`no_penerima`),
  ADD KEY `no_pengajuan` (`no_pengajuan`),
  ADD KEY `no_beasiswa` (`no_beasiswa`),
  ADD KEY `nis` (`nis`);

--
-- Indexes for table `bss_pengajuan`
--
ALTER TABLE `bss_pengajuan`
  ADD PRIMARY KEY (`no_pengajuan`),
  ADD KEY `no_beasiswa` (`no_beasiswa`),
  ADD KEY `no_user` (`no_user`);

--
-- Indexes for table `bss_peringkat`
--
ALTER TABLE `bss_peringkat`
  ADD PRIMARY KEY (`no_peringkat`);

--
-- Indexes for table `bss_prestasi`
--
ALTER TABLE `bss_prestasi`
  ADD PRIMARY KEY (`no_prestasi`),
  ADD KEY `nis` (`nis`),
  ADD KEY `no_peringkat` (`no_peringkat`);

--
-- Indexes for table `bss_siswa`
--
ALTER TABLE `bss_siswa`
  ADD PRIMARY KEY (`nis`),
  ADD UNIQUE KEY `no_user_2` (`no_user`),
  ADD KEY `no_user` (`no_user`),
  ADD KEY `no_kelas` (`no_kelas`),
  ADD KEY `no_jurusan` (`no_jurusan`);

--
-- Indexes for table `bss_syarat`
--
ALTER TABLE `bss_syarat`
  ADD PRIMARY KEY (`no_syarat`),
  ADD KEY `no_beasiswa` (`no_beasiswa`);

--
-- Indexes for table `bss_up_syarat`
--
ALTER TABLE `bss_up_syarat`
  ADD PRIMARY KEY (`no_upload`),
  ADD KEY `no_syarat` (`no_syarat`),
  ADD KEY `no_user` (`no_user`),
  ADD KEY `no_pengajuan` (`no_pengajuan`);

--
-- Indexes for table `bss_user`
--
ALTER TABLE `bss_user`
  ADD PRIMARY KEY (`no_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bss_comment`
--
ALTER TABLE `bss_comment`
  MODIFY `no_coment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `bss_peringkat`
--
ALTER TABLE `bss_peringkat`
  MODIFY `no_peringkat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `bss_prestasi`
--
ALTER TABLE `bss_prestasi`
  MODIFY `no_prestasi` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `bss_syarat`
--
ALTER TABLE `bss_syarat`
  MODIFY `no_syarat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `bss_f_profile`
--
ALTER TABLE `bss_f_profile`
  ADD CONSTRAINT `bss_f_profile_ibfk_1` FOREIGN KEY (`no_user`) REFERENCES `bss_user` (`no_user`);

--
-- Ketidakleluasaan untuk tabel `bss_guru`
--
ALTER TABLE `bss_guru`
  ADD CONSTRAINT `bss_guru_ibfk_1` FOREIGN KEY (`no_user`) REFERENCES `bss_user` (`no_user`),
  ADD CONSTRAINT `bss_guru_ibfk_2` FOREIGN KEY (`no_kelas`) REFERENCES `bss_kelas` (`no_kelas`);

--
-- Ketidakleluasaan untuk tabel `bss_kelas`
--
ALTER TABLE `bss_kelas`
  ADD CONSTRAINT `bss_kelas_ibfk_1` FOREIGN KEY (`no_jurusan`) REFERENCES `bss_jurusan` (`no_jurusan`);

--
-- Ketidakleluasaan untuk tabel `bss_penerima`
--
ALTER TABLE `bss_penerima`
  ADD CONSTRAINT `bss_penerima_ibfk_1` FOREIGN KEY (`nis`) REFERENCES `bss_siswa` (`nis`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bss_penerima_ibfk_2` FOREIGN KEY (`no_beasiswa`) REFERENCES `bss_beasiswa` (`no_beasiswa`);

--
-- Ketidakleluasaan untuk tabel `bss_pengajuan`
--
ALTER TABLE `bss_pengajuan`
  ADD CONSTRAINT `bss_pengajuan_ibfk_1` FOREIGN KEY (`no_beasiswa`) REFERENCES `bss_beasiswa` (`no_beasiswa`);

--
-- Ketidakleluasaan untuk tabel `bss_prestasi`
--
ALTER TABLE `bss_prestasi`
  ADD CONSTRAINT `bss_prestasi_ibfk_1` FOREIGN KEY (`nis`) REFERENCES `bss_siswa` (`nis`),
  ADD CONSTRAINT `bss_prestasi_ibfk_2` FOREIGN KEY (`no_peringkat`) REFERENCES `bss_peringkat` (`no_peringkat`);

--
-- Ketidakleluasaan untuk tabel `bss_siswa`
--
ALTER TABLE `bss_siswa`
  ADD CONSTRAINT `bss_siswa_ibfk_1` FOREIGN KEY (`no_user`) REFERENCES `bss_user` (`no_user`),
  ADD CONSTRAINT `bss_siswa_ibfk_2` FOREIGN KEY (`no_kelas`) REFERENCES `bss_kelas` (`no_kelas`),
  ADD CONSTRAINT `bss_siswa_ibfk_3` FOREIGN KEY (`no_jurusan`) REFERENCES `bss_jurusan` (`no_jurusan`);

--
-- Ketidakleluasaan untuk tabel `bss_syarat`
--
ALTER TABLE `bss_syarat`
  ADD CONSTRAINT `bss_syarat_ibfk_1` FOREIGN KEY (`no_beasiswa`) REFERENCES `bss_beasiswa` (`no_beasiswa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `bss_up_syarat`
--
ALTER TABLE `bss_up_syarat`
  ADD CONSTRAINT `bss_up_syarat_ibfk_1` FOREIGN KEY (`no_syarat`) REFERENCES `bss_syarat` (`no_syarat`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
